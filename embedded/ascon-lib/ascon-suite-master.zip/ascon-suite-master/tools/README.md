
This directory contains various tools to help create assembly code
backends for the library, to generate pre-formatted initialization
vectors, and to convert the entire library into Arduino form.

This directory uses its own custom make system.  It is not built as
part of the standard cmake build process.
